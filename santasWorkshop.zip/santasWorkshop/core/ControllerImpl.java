package santasWorkshop.core;

import santasWorkshop.common.ConstantMessages;
import santasWorkshop.common.ExceptionMessages;
import santasWorkshop.models.*;
import santasWorkshop.repositories.DwarfRepository;
import santasWorkshop.repositories.PresentRepository;

public class ControllerImpl implements Controller{
    private DwarfRepository dwarfRepository;
    private PresentRepository presentRepository;

    public ControllerImpl() {
        this.dwarfRepository = new DwarfRepository();
        this.presentRepository =  new PresentRepository();
    }

    @Override
    public String addDwarf(String type, String dwarfName) {
        Dwarf dwarf;
        if (type.equals("Happy")){
            dwarf = new Happy(dwarfName);
        }else if (type.equals("Sleepy")){
            dwarf = new Sleepy(dwarfName);
        }else {
            throw new IllegalArgumentException(ExceptionMessages.DWARF_TYPE_DOESNT_EXIST);
        }
        dwarfRepository.add(dwarf);
        return String.format(ConstantMessages.ADDED_DWARF, type, dwarfName);
    }

    @Override
    public String addInstrumentToDwarf(String dwarfName, int power) {
        Instrument instrument = new InstrumentImpl(power);

        Dwarf dwarf = dwarfRepository.findByName(dwarfName);
        if (dwarf == null){
            throw new IllegalArgumentException(ExceptionMessages.DWARF_DOESNT_EXIST);
        }
        dwarf.addInstrument(instrument);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_INSTRUMENT_TO_DWARF, power, dwarfName);
    }

    @Override
    public String addPresent(String presentName, int energyRequired) {
        Present present = new PresentImpl(presentName, energyRequired);
        presentRepository.add(present);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_PRESENT, presentName);
    }

    @Override
    public String craftPresent(String presentName) {
        boolean isTrue = true;
        WorkshopImpl workshop = new WorkshopImpl();
        Present present = presentRepository.findByName(presentName);
        for (Dwarf dwarf : dwarfRepository.getModels()) {
            if (dwarf.getEnergy() > 50){
                workshop.craft(present,dwarf);
                isTrue = false;
            }
        }
        if (isTrue){
            throw new IllegalArgumentException(ExceptionMessages.NO_DWARF_READY);
        }
        if (present.isDone()){
            return String.format(ConstantMessages.PRESENT_DONE + ConstantMessages.COUNT_BROKEN_INSTRUMENTS, presentName, "done", workshop.getCountBrokenInstruments());
        }else {
                return String.format(ConstantMessages.PRESENT_DONE + ConstantMessages.COUNT_BROKEN_INSTRUMENTS, presentName, "not done", workshop.getCountBrokenInstruments());
        }
    }

    @Override
    public String report() {
        int donePresents = 0;
        for (Present present : presentRepository.getModels()) {
            if (present.isDone()){
                donePresents++;
            }
        }
        String s = String.format("%d presents are done!%nDwarfs info:%n", donePresents);
        for (Dwarf dwarf : dwarfRepository.getModels()) {
            s += dwarf.toString();
        }
        return s;
    }
}
