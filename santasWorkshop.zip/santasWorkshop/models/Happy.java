package santasWorkshop.models;

public class Happy extends BaseDwarf{
    public Happy(String name) {
        super(name, 100);
    }
}
