package santasWorkshop.models;

public interface Workshop {
    void craft(Present present, Dwarf dwarf);
}
