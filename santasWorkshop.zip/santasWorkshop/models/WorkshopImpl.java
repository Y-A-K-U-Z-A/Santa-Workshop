package santasWorkshop.models;

import java.util.Collection;

public  class WorkshopImpl implements Workshop{
    int countBrokenInstruments;

    public WorkshopImpl() {
        countBrokenInstruments = 0;
    }

    @Override
    public void craft(Present present, Dwarf dwarf) {

if (dwarf.canWork()){
    Collection<Instrument> instruments = dwarf.getInstruments();
                for (Instrument instrument : instruments) {
                    while (!instrument.isBroken() && dwarf.canWork()) {
                        dwarf.work();
                        instrument.use();
                        present.getCrafted();
                        if (present.isDone()){
                            break;
                        }
                    }
                    if (present.isDone()){
                        break;
                    }
                    if (instrument.isBroken()){
                    countBrokenInstruments++;
                    }
                }
}
    }

    public int getCountBrokenInstruments(){
        return this.countBrokenInstruments;
    }
}
