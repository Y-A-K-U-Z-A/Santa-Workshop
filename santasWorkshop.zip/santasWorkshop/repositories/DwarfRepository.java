package santasWorkshop.repositories;

import santasWorkshop.models.BaseDwarf;
import santasWorkshop.models.Dwarf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class DwarfRepository implements Repository{
    private Collection<Dwarf> dwarfs;

    public DwarfRepository() {
        this.dwarfs = new ArrayList<>();
    }

    @Override
    public Collection<Dwarf> getModels() {
        return Collections
                .unmodifiableCollection(dwarfs);
    }

    @Override
    public void add(Object model) {
        dwarfs.add((Dwarf) model);
    }

    @Override
    public boolean remove(Object model) {
        if (containsDwarf((Dwarf) model)){
            dwarfs.remove(model);
            return true;
        }
        return false;
    }

    private boolean containsDwarf(Dwarf model) {
        for (Dwarf dwarf : dwarfs) {
            if (model.getName().equals(dwarf.getName())){
                return true;
            }
        }
        return false;
    }

    @Override
    public Dwarf findByName(String name) {
        for (Dwarf dwarf : dwarfs) {
            if (dwarf.getName().equals(name)){
                return dwarf;
            }
        }
        return null;
    }
}
