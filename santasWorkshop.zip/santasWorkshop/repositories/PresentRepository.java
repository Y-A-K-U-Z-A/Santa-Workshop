package santasWorkshop.repositories;

import santasWorkshop.models.Present;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class PresentRepository implements Repository{
    private Collection<Present> presents;

    public PresentRepository(){
        this.presents = new ArrayList<>();
    }

    @Override
    public Collection<Present> getModels() {
        return Collections.unmodifiableCollection(presents);
    }

    @Override
    public void add(Object model) {
        presents.add((Present) model);
    }

    @Override
    public boolean remove(Object model) {
        if (containsPresend((Present) model)){
            presents.remove((Present)model);
            return true;
        }
        return false;
    }

    private boolean containsPresend(Present model) {
        for (Present present : presents) {
            if (present.getName().equals(model.getName())){
                return true;
            }
        }
        return false;
    }

    @Override
    public Present findByName(String name) {
        for (Present present : presents) {
            if (present.getName().equals(name)){
                return present;
            }
        }
        return null;
    }
}
